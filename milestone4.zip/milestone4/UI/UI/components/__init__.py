"""Reusable Streamlit UI components."""
